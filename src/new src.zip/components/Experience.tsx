"use client";

import { motion } from "framer-motion";
import { Briefcase, Calendar, CheckCircle2 } from "lucide-react";

const experiences = [
  {
    role: "Freelance Front-End Developer",
    company: "Freelance / Client Projects",
    period: "2025 - Present",
    points: [
      "Built responsive websites and web applications using React, Next.js, JavaScript, Tailwind CSS, Bootstrap, and REST APIs.",
      "Created ecommerce interfaces, authentication flows, dynamic routes, checkout screens, dashboards, and Arabic RTL layouts.",
      "Integrated APIs with Axios and React Query using organized services, hooks, loading states, and error handling.",
    ],
  },
  {
    role: "Front-End Learning & Practice",
    company: "Personal Projects",
    period: "2025",
    points: [
      "Focused on real-world project structure with reusable components, custom hooks, Context API, and local storage flows.",
      "Practiced deployment, GitHub workflows, mobile responsive design, and improving UI polish from feedback.",
    ],
  },
];

export function Experience() {
  return (
    <section id="experience" className="relative px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <span className="section-kicker">
            <Briefcase size={13} />
            Experience
          </span>
          <h2 className="mt-4 text-3xl font-black tracking-tight text-slate-950 dark:text-white sm:text-5xl">
            Practical front-end experience
          </h2>
          <p className="mx-auto mt-4 max-w-2xl leading-8 text-slate-600 dark:text-slate-300">
            My experience is focused on building real interfaces, improving project quality, and turning learning into shipped projects.
          </p>
        </motion.div>

        <div className="relative space-y-6">
          <div className="absolute left-5 top-2 hidden h-[calc(100%-1rem)] w-px bg-slate-200 dark:bg-white/10 md:block" />
          {experiences.map((exp, index) => (
            <motion.article
              key={exp.role}
              initial={{ opacity: 0, x: -18 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="relative md:pl-14"
            >
              <div className="absolute left-0 top-8 hidden h-10 w-10 items-center justify-center rounded-2xl border border-blue-500/20 bg-blue-600 text-white shadow-lg shadow-blue-600/20 md:flex">
                <Briefcase size={18} />
              </div>
              <div className="spotlight-card rounded-[2rem] border border-slate-200 bg-white/80 p-6 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/[0.04] sm:p-8">
                <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                  <div>
                    <h3 className="text-2xl font-black text-slate-950 dark:text-white">{exp.role}</h3>
                    <p className="mt-1 font-semibold text-blue-600 dark:text-blue-300">{exp.company}</p>
                  </div>
                  <div className="inline-flex w-fit items-center gap-2 rounded-full bg-blue-500/10 px-4 py-2 text-sm font-bold text-blue-700 dark:text-blue-300">
                    <Calendar size={15} />
                    {exp.period}
                  </div>
                </div>

                <ul className="mt-6 space-y-3">
                  {exp.points.map((point) => (
                    <li key={point} className="flex gap-3 leading-7 text-slate-600 dark:text-slate-300">
                      <CheckCircle2 className="mt-1 shrink-0 text-blue-600 dark:text-blue-300" size={18} />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
