"use client";

import { motion } from "framer-motion";
import { SiCss, SiHtml5, SiJavascript, SiNextdotjs, SiReact, SiTailwindcss, SiTypescript, SiVercel, SiAxios, SiReactquery } from "react-icons/si";
import { FaGitAlt, FaGithub } from "react-icons/fa";

const stack = [
  { name: "HTML5", icon: SiHtml5, color: "text-orange-500" },
  { name: "CSS3", icon: SiCss, color: "text-blue-500" },
  { name: "JavaScript", icon: SiJavascript, color: "text-yellow-400" },
  { name: "TypeScript", icon: SiTypescript, color: "text-blue-500" },
  { name: "React", icon: SiReact, color: "text-cyan-400" },
  { name: "Next.js", icon: SiNextdotjs, color: "text-slate-950 dark:text-white" },
  { name: "Tailwind", icon: SiTailwindcss, color: "text-cyan-400" },
  { name: "React Query", icon: SiReactquery, color: "text-red-400" },
  { name: "Axios", icon: SiAxios, color: "text-purple-500" },
  { name: "Git", icon: FaGitAlt, color: "text-orange-500" },
  { name: "GitHub", icon: FaGithub, color: "text-slate-950 dark:text-white" },
  { name: "Vercel", icon: SiVercel, color: "text-slate-950 dark:text-white" },
];

const skillGroups = [
  "Responsive Design",
  "API Integration",
  "Authentication UI",
  "Cart & Checkout Flow",
  "Reusable Components",
  "Clean Project Structure",
  "Arabic RTL Layouts",
  "Deployment & GitHub",
];

export function Skills() {
  return (
    <section id="skills" className="relative px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <span className="section-kicker">Tech Stack</span>
          <h2 className="mt-4 text-3xl font-black tracking-tight text-slate-950 dark:text-white sm:text-5xl">
            Tools I use to build modern interfaces
          </h2>
          <p className="mx-auto mt-4 max-w-3xl leading-8 text-slate-600 dark:text-slate-300">
            A focused frontend stack for building responsive pages, connecting APIs, managing server state, and shipping polished user experiences.
          </p>
        </motion.div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-[1.1fr_0.9fr]">
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="spotlight-card rounded-[2rem] border border-slate-200 bg-white/80 p-5 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/[0.04] sm:p-7"
          >
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
              {stack.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, scale: 0.92 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.35, delay: index * 0.035 }}
                    className="group rounded-3xl border border-slate-200 bg-slate-50/80 p-4 text-center transition hover:-translate-y-1 hover:border-blue-500/30 hover:bg-blue-500/5 dark:border-white/10 dark:bg-slate-950/40 dark:hover:bg-blue-500/10"
                  >
                    <Icon className={`mx-auto mb-3 text-3xl ${item.color}`} />
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300 sm:text-sm">{item.name}</p>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.1 }}
            className="spotlight-card rounded-[2rem] border border-slate-200 bg-white/80 p-7 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/[0.04]"
          >
            <h3 className="text-2xl font-black text-slate-950 dark:text-white">What I can deliver</h3>
            <p className="mt-3 leading-7 text-slate-600 dark:text-slate-300">
              I focus on practical implementation: clean layouts, real API flows, and UI that works well on mobile and desktop.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              {skillGroups.map((skill) => (
                <span
                  key={skill}
                  className="rounded-full border border-blue-500/15 bg-blue-500/10 px-4 py-2 text-sm font-bold text-blue-700 dark:text-blue-300"
                >
                  {skill}
                </span>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
