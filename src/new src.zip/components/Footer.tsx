import Link from "next/link";
import { Mail, MessageCircle } from "lucide-react";

function GithubIcon({ size = 19, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      fill="currentColor"
    >
      <path d="M12 2C6.48 2 2 6.58 2 12.26c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49v-1.73c-2.78.62-3.37-1.37-3.37-1.37-.45-1.18-1.11-1.5-1.11-1.5-.91-.64.07-.63.07-.63 1 .07 1.53 1.06 1.53 1.06.9 1.57 2.36 1.12 2.94.86.09-.67.35-1.12.63-1.38-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.71 0 0 .84-.28 2.75 1.05A9.3 9.3 0 0 1 12 6.99c.85 0 1.7.12 2.5.34 1.9-1.33 2.74-1.05 2.74-1.05.55 1.41.2 2.45.1 2.71.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.8-4.57 5.06.36.32.68.95.68 1.92v2.84c0 .27.18.59.69.49A10.1 10.1 0 0 0 22 12.26C22 6.58 17.52 2 12 2Z" />
    </svg>
  );
}

function LinkedinIcon({ size = 19, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      fill="currentColor"
    >
      <path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.95v5.66H9.34V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.32 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12Zm1.78 13.02H3.54V9H7.1v11.45ZM22.23 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.72V1.72C24 .77 23.21 0 22.23 0Z" />
    </svg>
  );
}

const quickLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

const socials = [
  { label: "GitHub", href: "https://github.com/petersalah1", icon: GithubIcon },
  { label: "LinkedIn", href: "https://www.linkedin.com/in/petersalah/", icon: LinkedinIcon },
  { label: "Email", href: "mailto:petersalah104@gmail.com", icon: Mail },
  { label: "WhatsApp", href: "https://wa.me/201204995735", icon: MessageCircle },
];

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white/80 py-10 text-slate-600 backdrop-blur dark:border-white/10 dark:bg-slate-950/80 dark:text-slate-400">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 sm:px-6 md:grid-cols-[1.2fr_0.8fr_1fr] lg:px-8">
        <div>
          <Link href="#home" className="inline-flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-600 text-lg font-black text-white shadow-lg shadow-blue-600/25">
              P
            </span>
            <span className="text-lg font-black text-slate-950 dark:text-white">Peter Salah</span>
          </Link>
          <p className="mt-4 max-w-md leading-7">
            Front-End Developer building clean, responsive, API-driven web applications with React, Next.js, and Tailwind CSS.
          </p>
        </div>

        <div>
          <h3 className="font-black text-slate-950 dark:text-white">Quick Links</h3>
          <div className="mt-4 grid gap-2">
            {quickLinks.map((link) => (
              <a key={link.href} href={link.href} className="w-fit text-sm font-semibold transition hover:text-blue-600 dark:hover:text-blue-300">
                {link.label}
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-black text-slate-950 dark:text-white">Connect</h3>
          <div className="mt-4 flex flex-wrap gap-3">
            {socials.map((item) => {
              const Icon = item.icon;
              return (
                <a
                  key={item.label}
                  href={item.href}
                  target={item.href.startsWith("http") ? "_blank" : undefined}
                  rel={item.href.startsWith("http") ? "noreferrer" : undefined}
                  aria-label={item.label}
                  className="flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-slate-600 transition hover:-translate-y-1 hover:border-blue-500/30 hover:text-blue-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:text-blue-300"
                >
                  <Icon size={19} />
                </a>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mx-auto mt-8 max-w-7xl border-t border-slate-200 px-4 pt-6 text-sm dark:border-white/10 sm:px-6 lg:px-8">
        <p>
          © {new Date().getFullYear()} Peter Salah. Built with Next.js, Tailwind CSS, and care.
        </p>
      </div>
    </footer>
  );
}