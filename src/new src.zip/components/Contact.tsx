"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, Mail, MessageCircle, Send } from "lucide-react";

function GithubIcon({ size = 19, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      fill="currentColor"
    >
      <path d="M12 2C6.48 2 2 6.58 2 12.26c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49v-1.73c-2.78.62-3.37-1.37-3.37-1.37-.45-1.18-1.11-1.5-1.11-1.5-.91-.64.07-.63.07-.63 1 .07 1.53 1.06 1.53 1.06.9 1.57 2.36 1.12 2.94.86.09-.67.35-1.12.63-1.38-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.71 0 0 .84-.28 2.75 1.05A9.3 9.3 0 0 1 12 6.99c.85 0 1.7.12 2.5.34 1.9-1.33 2.74-1.05 2.74-1.05.55 1.41.2 2.45.1 2.71.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.8-4.57 5.06.36.32.68.95.68 1.92v2.84c0 .27.18.59.69.49A10.1 10.1 0 0 0 22 12.26C22 6.58 17.52 2 12 2Z" />
    </svg>
  );
}

function LinkedinIcon({ size = 19, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      fill="currentColor"
    >
      <path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.95v5.66H9.34V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.32 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12Zm1.78 13.02H3.54V9H7.1v11.45ZM22.23 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.72V1.72C24 .77 23.21 0 22.23 0Z" />
    </svg>
  );
}

const contactMethods = [
  {
    label: "Email",
    value: "petersalah104@gmail.com",
    href: "mailto:petersalah104@gmail.com",
    icon: Mail,
  },
  {
    label: "WhatsApp",
    value: "+20 120 499 5735",
    href: "https://wa.me/201204995735",
    icon: MessageCircle,
  },
  {
    label: "GitHub",
    value: "github.com/petersalah1",
    href: "https://github.com/petersalah1",
    icon: GithubIcon,
  },
  {
    label: "LinkedIn",
    value: "linkedin.com/in/petersalah",
    href: "https://www.linkedin.com/in/petersalah/",
    icon: LinkedinIcon,
  },
];

export function Contact() {
  return (
    <section id="contact" className="relative px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
          className="spotlight-card overflow-hidden rounded-[2rem] border border-slate-200 bg-white/80 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/[0.04]"
        >
          <div className="grid gap-0 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="relative overflow-hidden bg-blue-600 p-8 text-white sm:p-10">
              <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-white/15 blur-3xl" />
              <div className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-cyan-300/20 blur-3xl" />
              <div className="relative z-10">
                <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-xs font-black uppercase tracking-[0.2em]">
                  <Send size={14} />
                  Let&apos;s work together
                </span>
                <h2 className="mt-6 text-3xl font-black tracking-tight sm:text-5xl">
                  Have a project or opportunity?
                </h2>
                <p className="mt-5 leading-8 text-blue-50">
                  I am open to freelance work, internships, and junior front-end roles. Send me a message and I will get back to you as soon as possible.
                </p>
                <a
                  href="mailto:petersalah104@gmail.com"
                  className="mt-8 inline-flex items-center rounded-2xl bg-white px-6 py-4 text-sm font-black text-blue-600 transition hover:-translate-y-0.5"
                >
                  Send an Email
                  <ArrowUpRight className="ml-2" size={17} />
                </a>
              </div>
            </div>

            <div className="grid gap-4 p-6 sm:grid-cols-2 sm:p-8">
              {contactMethods.map((method, index) => {
                const Icon = method.icon;
                return (
                  <motion.a
                    key={method.label}
                    href={method.href}
                    target={method.href.startsWith("http") ? "_blank" : undefined}
                    rel={method.href.startsWith("http") ? "noreferrer" : undefined}
                    initial={{ opacity: 0, y: 18 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    className="group rounded-3xl border border-slate-200 bg-slate-50/80 p-5 transition hover:-translate-y-1 hover:border-blue-500/30 hover:bg-blue-500/5 dark:border-white/10 dark:bg-slate-950/40 dark:hover:bg-blue-500/10"
                  >
                    <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/25">
                      <Icon size={21} />
                    </div>
                    <h3 className="font-black text-slate-950 dark:text-white">{method.label}</h3>
                    <p className="mt-2 break-words text-sm leading-6 text-slate-600 dark:text-slate-300">{method.value}</p>
                  </motion.a>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}