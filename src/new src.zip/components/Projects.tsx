"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight, ExternalLink, ShoppingCart, GraduationCap, Plane } from "lucide-react";

function GithubIcon({ size = 19, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      fill="currentColor"
    >
      <path d="M12 2C6.48 2 2 6.58 2 12.26c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49v-1.73c-2.78.62-3.37-1.37-3.37-1.37-.45-1.18-1.11-1.5-1.11-1.5-.91-.64.07-.63.07-.63 1 .07 1.53 1.06 1.53 1.06.9 1.57 2.36 1.12 2.94.86.09-.67.35-1.12.63-1.38-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.71 0 0 .84-.28 2.75 1.05A9.3 9.3 0 0 1 12 6.99c.85 0 1.7.12 2.5.34 1.9-1.33 2.74-1.05 2.74-1.05.55 1.41.2 2.45.1 2.71.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.8-4.57 5.06.36.32.68.95.68 1.92v2.84c0 .27.18.59.69.49A10.1 10.1 0 0 0 22 12.26C22 6.58 17.52 2 12 2Z" />
    </svg>
  );
}


const projects = [
  {
    title: "NextShop",
    badge: "Featured",
    description:
      "A full ecommerce platform with authentication, product browsing, cart, wishlist, cash checkout, online Stripe checkout, and user orders.",
    image:
      "https://api.microlink.io/?url=https%3A%2F%2Fnext-shop21.vercel.app%2F&screenshot=true&meta=false&embed=screenshot.url",
    icon: ShoppingCart,
    tags: ["Next.js", "React Query", "Tailwind", "Auth", "Checkout"],
    demoLink: "https://next-shop21.vercel.app/",
    githubLink: "https://github.com/petersalah1/nextShop",
  },
  {
    title: "Ahmed Megaly Platform",
    badge: "Client-style",
    description:
      "Arabic RTL educational platform with courses, lessons, exams, protected video pages, store, checkout, and API integration.",
    image:
      "https://api.microlink.io/?url=https%3A%2F%2Fahmedmegaly.sck.guru%2F&screenshot=true&meta=false&embed=screenshot.url",
    icon: GraduationCap,
    tags: ["Next.js", "RTL", "React Query", "Protected Routes"],
    demoLink: "https://ahmedmegaly.sck.guru/",
    githubLink: "",
  },
  {
    title: "Nivirra Tourism",
    badge: "UI Project",
    description:
      "Responsive tourism website featuring trips, offers, traveler feedback, maps, and an interactive tailor-made tour request flow.",
    image:
      "https://api.microlink.io/?url=https%3A%2F%2Fpetersalah1.github.io%2FNivirra%2Findex.html&screenshot=true&meta=false&embed=screenshot.url",
    icon: Plane,
    tags: ["HTML", "CSS", "JavaScript", "Responsive"],
    demoLink: "https://petersalah1.github.io/Nivirra/index.html",
    githubLink: "",
  },
];

export function Projects() {
  return (
    <section id="projects" className="relative px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 flex flex-col gap-5 md:flex-row md:items-end md:justify-between"
        >
          <div>
            <span className="section-kicker">Featured Projects</span>
            <h2 className="mt-4 text-3xl font-black tracking-tight text-slate-950 dark:text-white sm:text-5xl">
              Real projects, real flows
            </h2>
            <p className="mt-4 max-w-2xl leading-8 text-slate-600 dark:text-slate-300">
              A small but strong collection focused on ecommerce, API integration, responsive UI, and production-style user flows.
            </p>
          </div>
          <a
            href="https://github.com/petersalah1"
            target="_blank"
            rel="noreferrer"
            className="inline-flex w-fit items-center rounded-2xl border border-blue-500/20 px-5 py-3 text-sm font-bold text-blue-600 transition hover:bg-blue-500/10 dark:text-blue-300"
          >
            View GitHub
            <ArrowUpRight className="ml-2" size={17} />
          </a>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-3">
          {projects.map((project, index) => {
            const Icon = project.icon;
            return (
              <motion.article
                key={project.title}
                initial={{ opacity: 0, y: 26 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: index * 0.08 }}
                className="spotlight-card group flex overflow-hidden rounded-[2rem] border border-slate-200 bg-white/80 shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-2xl hover:shadow-blue-950/10 dark:border-white/10 dark:bg-white/[0.04]"
              >
                <div className="flex w-full flex-col">
                  <div className="relative h-56 overflow-hidden bg-slate-900">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="h-full w-full object-cover object-top opacity-90 transition duration-700 group-hover:scale-105"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).style.display = "none";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/10 to-transparent" />
                    <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full bg-white/90 px-3 py-1.5 text-xs font-black text-slate-900 backdrop-blur">
                      <Icon size={15} className="text-blue-600" />
                      {project.badge}
                    </div>
                  </div>

                  <div className="flex flex-1 flex-col p-6">
                    <h3 className="text-2xl font-black text-slate-950 dark:text-white">{project.title}</h3>
                    <p className="mt-3 flex-1 leading-7 text-slate-600 dark:text-slate-300">{project.description}</p>

                    <div className="mt-6 flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <span key={tag} className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-700 dark:bg-white/10 dark:text-slate-300">
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="mt-7 flex gap-3">
                      <Link
                        href={project.demoLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex flex-1 items-center justify-center rounded-2xl bg-blue-600 px-4 py-3 text-sm font-bold text-white transition hover:bg-blue-500"
                      >
                        Live Demo
                        <ExternalLink className="ml-2" size={16} />
                      </Link>
                      {project.githubLink && (
                        <Link
                          href={project.githubLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-200 text-slate-700 transition hover:border-blue-500/30 hover:text-blue-600 dark:border-white/10 dark:text-slate-300 dark:hover:text-blue-300"
                          aria-label={`${project.title} GitHub repository`}
                        >
                          <GithubIcon size={20} />
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}